#ifndef _NODE_H
#define _NODE_H
using namespace std;
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <list>
#include <climits>
#include <vector>

class Node{
	public:
	~Node();
	Node();
	 Node(string s, int d);

	void  setSpCount(int a);
	void  setScanned(bool a);
	void  setInSp(bool a);
	void  setValue(int a);
	void  setDistance(int a);
	
	void  setHeapIndex(int a);

	int  getHeapIndex();
	
	bool  getScanned();
	bool  getInSp();
	int  getDistance();
	int  getSpCount();

	int  getValue();
	string  getName();
	int  getId();
		
	private:
		
		string nname;
		int id;
		int distance;
		
		int value;
		int spCount;
		int heapindex;
		
		bool isScanned;
		bool inSp;
		list <Node> adj;
};
#endif

